const caixaPrincipal = document.querySelector(".caixa-principal");
const caixaPerguntas = document.querySelector(".caixa-perguntas");
const caixaAlternativas = document.querySelector(".caixa-alternativas");
const caixaResultado = document.querySelector(".caixa-resultado");
const textoResultado = document.querySelector(".texto-resultado"); 

const perguntas = [
{
enunciado: "No início da sua missão, você descobre que uma Inteligência Artificial avançada foi desativada misteriosamente em um laboratório. Qual o seu primeiro passo para investigar?",
alternativas: [
{
texto: "Analisar as linhas de código e os logs do sistema em busca de erros de execução.",
afirmacao: "Você optou por uma abordagem técnica, identificando falhas na inicialização do sistema através da leitura minuciosa de dados."
},
{
texto: "Conversar com a equipe de cientistas para entender o comportamento da IA antes do apagão.",
afirmacao: "Você preferiu focar no fator humano e no contexto social, coletando pistas importantes sobre as últimas interações com a máquina."
}
]
},
{
enunciado: "Ao reativar o núcleo, a IA pergunta se deve priorizar a automação de tarefas industriais repetitivas ou o suporte criativo a artistas humanos. O que você escolhe?",
alternativas: [
{
texto: "Priorizar a automação industrial para reduzir falhas operacionais humanas.",
afirmacao: "Decidiu focar na eficiência mecânica, otimizando os processos industriais com precisão matemática."
},
{
texto: "Priorizar o suporte criativo, ajudando artistas a criarem novas obras.",
afirmacao: "Escolheu expandir o horizonte da IA generativa, estimulando a colaboração artística entre humanos e computadores."
}
]
},
{
enunciado: "Sua missão chega ao fim. Para garantir que essa Inteligência Artificial continue segura e ética no futuro, qual diretriz você implementa?",
alternativas: [
{
texto: "Criar um comitê de governança humana que supervisiona e aprova cada grande decisão da IA.",
afirmacao: "Por fim, determinou que o controle ético sempre permaneça sob a responsabilidade e o julgamento humano."
},
{
texto: "Programar algoritmos de autoajuste de segurança que corrigem preconceitos automaticamente.",
afirmacao: "Por fim, confiou no poder da automação avançada e em guardrails matemáticos autoexecutáveis para manter a integridade do sistema."
}
]
}
]; 

let atual = 0;
let perguntaAtual;
let historiaFinal = ""; 

function mostraPergunta() {
if (atual >= perguntas.length) {
mostraResultado();
return;
}
perguntaAtual = perguntas[atual];
caixaPerguntas.textContent = perguntaAtual.enunciado;
caixaAlternativas.textContent = "";
mostraAlternativas();
} 

function mostraAlternativas() {
for (const alternativa of perguntaAtual.alternativas) {
const botaoAlternativas = document.createElement("button");
botaoAlternativas.textContent = alternativa.texto;
botaoAlternativas.addEventListener("click", () => respostaSelecionada(alternativa));
caixaAlternativas.appendChild(botaoAlternativas);
}
} 

function respostaSelecionada(opcaoSelecionada) {
const afirmacoes = opcaoSelecionada.afirmacao;
historiaFinal += afirmacoes + " ";
atual++;
mostraPergunta();
} 

function mostraResultado() {
caixaPerguntas.textContent = "Missão Cumprida! O relatório final da sua IA indica:";
textoResultado.textContent = historiaFinal;
caixaAlternativas.textContent = "";
} 

mostraPergunta();